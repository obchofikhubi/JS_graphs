const pause = (timeoutMsec) => new Promise(resolve => setTimeout(resolve, timeoutMsec));
class Engine  {
    m_SleepTime = 100;  // Z�rove� je tam psan� jako SAMPLE PERIOD

    all_cont_Params = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "U"];  // "D", "W", "U",

    allParamsEngine = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "D", "W", "U"];  // lze odmazat mo�n�, duplik�t ze scriptovou prom�nnou

    m_System = null; //Analog system
       
    m_Controller = null; //Controller

    m_W = 0.0; //float

    m_D = 0.0;  //float


    m_bPause = false; //bool

    SetD(D) {
        this.m_D = D;
        if (this.m_D > this.m_System.m_fDMax) {  // hodnoty se limituj� p��mo v syst�mu, ale mo�n� chceme limitovat i D v Enginu?? potom je pot�eba to d�t nakonec this.m_D
            this.m_D = this.m_System.m_fDMax;
        }
        if (this.m_D < this.m_System.m_fDMin) {
            this.m_D = this.m_System.m_fDMin;
         
        }

        if (this.m_System != null)
            this.m_System.setD(this.m_D);
    }

    SetW(W) {
        this.m_W = W;
        if (this.m_Controller != null)
            this.m_Controller.setW(this.m_W); // stejn� p�i�azen� je i p�i p�id�len� regul�toru, v SET W to nen� limitovan� jako u syst�mu!!!!!, asi nechat ten provizorn� nad t�mhle
        if (this.m_System != null)
            this.m_System.setW(this.m_W);

    }

    SetSystem(system) { //param: AnalogSystem
        this.m_System = system;
        if (system != null)
            this.m_System.setD(this.m_D);
    }

    SetController(controller) { //param: Controller
        this.m_Controller = controller;
        if (controller != null) {
            this.contChanged(this.m_Controller); // p�i zm�n� regul�toru spustit a zviditelnit jen n�kter� v�ci??, vol� se i kdy� se "nem�n�"
            this.m_Controller.setW(this.m_W);  //pokud by se dalo nad contChanged, tak si dal�� regul�tor pamatuje p�edchoz� W
        }
            
    }

    SetSamplePeriod(SamplePeriod) { //param: long, POUZIVAME TO NEKDE???
        this.m_SleepTime = SamplePeriod;
    }
        constructor() {
            console.log("vytvo�en engine");
        }
        
DoCycle() {
    //setInterval(() => {
        let y = 0.0;
        let u = 0.0;

        if (this.m_System != null) {
            y = this.m_System.get_Y();
        }
        if (this.m_Controller != null) {
            this.m_Controller.setY(y);
            u = this.m_Controller.getU();  // tady probl�m s manual controllerem
        }
        if (this.m_System != null)
        this.m_System.setU(u);
    addValue1(y);
   // }, 1000);
}


   async run() {
       while (!this.m_bPause) {
           this.DoCycle();
           await pause(100);  // tady vzorkujeme
        }
        
    }

    Pause(bPause) { //param: bool
        this.m_bPause = bPause;
        if (!bPause)
            resume();
    }

    contChanged(changedCont) {
       // Mo�nost zvolit po��te�n� y??
        this.hideAllParams();
        this.showContParams(changedCont);
        this.showRestParams();
    }

    hideAllParams() {  
        for (var i = 0; i < this.allParamsEngine.length; i++) {
            document.getElementById(this.allParamsEngine[i] + "-row").style.display = "none";  
            document.getElementById(allParams[i] + "-user").value = "";  //reset v�echn hodnot od u�ivatele
            document.getElementById(allParams[i] + "-val").innerHTML = 0;  // pozor, v pam�ti asi z�stane n�co jin�ho (regul�tor vytv���me v�dy nov�, lze upravit)
        }

    }

    showContParams(changedCont) {
        for (var i = 0; i < changedCont.array_of_params.length; i++) {
            document.getElementById(changedCont.array_of_params[i] + "-row").style.display = "table-row";           
        }
    }
    showRestParams() {
       // document.getElementById( "U-row").style.display = "table-row";  // U p�em�st�no k volb� u manu�ln�ho
        document.getElementById("D-row").style.display = "table-row";
        document.getElementById("W-row").style.display = "table-row";
        console.log("Engine W je: " + this.m_W);
    }
}


