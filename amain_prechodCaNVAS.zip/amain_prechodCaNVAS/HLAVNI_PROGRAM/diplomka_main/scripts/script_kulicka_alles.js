// PARAMETRY!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// mo�n� �patn� m�t glob�ln� prom�nn�?? p��padn� jde n�jak zapouzd�it ( p��stupn� p�es window.par
par_Su_val = 1.6;
par_Sd_val = 0;

par_a0_val = 0;   // POZOR, NEBYLO TO NIKDE, // 1 - statick� soustava, 0 - astatick� soustava

par_a1_val = 0;
par_a2_val = 1;
par_a3_val = 0;
par_a4_val = 0;
par_Astatic_val = true;  //?? yes
par_dT_val = 0.3;
par_DMin_val = -5;
par_DMax_val = 5;
par_WMin_val = -150;
par_WMax_val = 150;
par_UMin_val = -5;
par_UMax_val = 5;  // toto nutno p�ev�st do syst�mu (d�l� to v konstruktoru!) z toho si to pak bere Engine a limituje set D/W a nevim jak U????
par_YMin_val = 150;
par_YMax_val = 150;


par_PR0 = {
    val: 0.05,
    min: 0,
    max: 5
};
par_ITi = {
    val: 20000,
    min: 1,
    max: 50000
};
par_PIR0 = {
    val: 0.05,
    min: 0,
    max: 1
};
par_PITi = {
    val: 5,
    min: 1,
    max: 99
};
par_PDR0 = {
    val: 0.05,
    min: 0,
    max: 5
};
par_PDTd = {
    val: 7,
    min: 0,
    max: 10
};
par_PIDR0 = {
    val: 0.05,
    min: 0,
    max: 2
};
par_PIDTi = {
    val: 60,
    min: 1,
    max: 99
};
par_PIDTd = {
    val: 14,
    min: 0,
    max: 50
};
par_Pol2Hyst = {  // p�edtim bylo POL, upraveno aby se shodovalo s konstruktorem
    val: 10,
    min: 1,
    max: 100
};
par_Pol2Umax = {
    val: 0.5,
    min: -5,
    max: 5
};
par_Pol2Umin = {
    val: -0.5,
    min: -5,
    max: 5
};
par_Pol3Hyst = {
    val: 10,
    min: 1,
    max: 100
};
par_Pol3Necit = {
    val: 30,
    min: 0,
    max: 50
};
par_Pol3Umax = {
    val: 0.5,
    min: -5,
    max: 5
};
par_Pol3Ustr = {
    val: 0,
    min: -5,
    max: 5
};
par_Pol3Umin = {
    val: -0.5,
    min: -5,
    max: 5
};


//parametry kruhu a linky

let centerX = 250;  // mo�n� v�echno p�eto�it? nebo se tam Y zna�� vlastn� sou�adnice x??
let centerY = 250;   // p�edtim 83!, zjistit co je spr�vn�
let circleX = 0;
let circleY = 0;
let l = 240;  // 300
let R = 15;
let fi = 0; // p�epsat, zkontrolovat radiany atd



/////////////////////////////////////////////////////////////////////////////////////////


const canvas = document.querySelector('canvas');
canvas.width = 500;
canvas.height = 500;
const c = canvas.getContext('2d')

c.fillStyle = "blue";
c.fillRect(0, 0, canvas.width, canvas.height);


const linka = document.querySelector("#linka1");
const kruh = document.querySelector("#kruh");

function updateLine(uhelDeg) {
   
    anime({
        targets: linka,
        rotate: uhelDeg,
        transformOrigin: ['50% 30%', '50% 30%']  // p�ijde mi to trochu posunut� doprava!!!, NUTNO DOPOCITAT... 50,50 je asi �patn�, bran� od rohu svg??
    });
}


function updateCircle(x, y) {

    anime({
        targets: kruh,
        translateX: x-250,
        translateY: y-84,
    });
}

function radians_to_degrees(radians) {
    var pi = Math.PI;
    return radians * (180 / pi);
}

function MAIN() {  // tohle je �patn�, main mus� b�t stejn� pro v�echny, jen system.draw(); ??
    
    systemKulicka.vypocetStredu();  // asi upravit!!

    // SVG!!
    fi_deg = radians_to_degrees(fi);
    updateLine(fi_deg);
    updateCircle(circleX, circleY-165);  // pro svg ode�teno aby vych�zelo pixelov�
    //SVG!!

    //tady canvas
    systemKulicka.draw();
}


stopButton = document.querySelector("#stop-button");
stopButton.addEventListener('click', () => {
    stop();
});
mainButton = document.querySelector("#main-button");
mainButton.addEventListener('click', () => {  
    animate();
    start();
});

confButton = document.querySelector("#conf-button");
confButton.addEventListener('click', () => {
    confirm();
})

const allParams = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "D", "W", "U"];  //lze pou��t taky mainEngine.allParams, nev�m co je efektivn�j�� ////"D", "W", "U",
const contParams = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "U"];  // U br�no pro manual jako parametr cont??


function confirm() { 
    if (mainEngine.m_Controller != null) {
        console.log(mainEngine.m_System.m_fWMax);
        for (var i = 0; i < allParams.length; i++) { 

            let userVal = document.getElementById(allParams[i] + "-user").value;
           
                if (userVal != "") {  // neni prazdny vstup, v�echny by se m�li p�edtim vyresetovat kdy� se d�v� display.none
                    document.getElementById(allParams[i] + "-val").innerHTML = userVal;

                    if (allParams[i] === "D") {
                        mainEngine.SetD(parseInt(userVal));
                    }
                    else if (allParams[i] === "W") {  // CHCEME LIMITOVAT JEN VSTUP, ALE NE VYPO��TAN� W
                        userVal = limit(userVal, par_WMin_val, par_WMax_val);
                        console.log(userVal);
                        mainEngine.SetW(parseInt(userVal));  // engine u� dosad� W do syst�mu i regul�toru limitovan�, pak n�jak sjednotit, n�kde jsou 2x limitace
                    }
                    else if (allParams[i] === "U") { 
                        mainEngine.m_System.setU(parseInt(userVal));
                        mainEngine.m_Controller.setU(parseInt(userVal));  // rozd�len� kv�li manu�ln�mu ��zen�, jin� regul�tory nemaj� setter setU!
                    }
                    else {
                        let name = mainEngine.m_Controller.constructor.name; // t�eba PIController!!, nutno ode��st controller??
                        let wtf = name.search("Controller");
                        let cutted = name.slice(0, wtf);  // z�stane n�m jen n�zev regul�toru ( P,PI,Pol2,Pol3 
                        let finalName = "par_" + cutted + allParams[i];
                        let val = parseInt(userVal);
                        let minVal = window[finalName]["min"]; // asi ud�lat n�jakou global class a� nevstupujeme do window pro parametry???
                        let maxVal = window[finalName]["max"];
                 
                        let limitedVal = limit(val, minVal, maxVal);  // vol� limit z Controllers (je tam jako function)
                        mainEngine.m_Controller["set" + allParams[i]](limitedVal); //vol� setter
                    }
                }            
        }
    }
    else {
        console.log("Controller not set!");
    }
    console.log(mainEngine);
}

function animate() {
    animationId = window.requestAnimationFrame(animate);
    MAIN();
}

class Kulicka1D extends AbstractSystem {  // upravit

    vypocetStredu() {
        //test
        if (this.m_fU > this.m_fUMax) {        ///////////////////////////////////////////////// nen� tu tahle limitace zbyte�n�??
            this.m_fU = this.m_fUMax;
        }
        if (this.m_fU < this.m_fUMin) {  // antiwindup, nebo n�co jin�ho?
            this.m_fU = this.m_fUMin;
        }
        fi = this.m_fU * this.m_fSu / (this.m_fUMax - this.m_fUMin) * this.m_fSu / 2.0 * 0.7853981633974483;
        // takhle to je podle pana Trnky, nev�m pro� ode�t�tat R...
        //circleX = centerX - R + this.m_fY * Math.cos(fi) + R * Math.sin(fi);
        //circleY = centerY - R + this.m_fY * Math.sin(fi) - R * Math.cos(fi);
        circleX = centerX + this.m_fY * Math.cos(fi); // + R * Math.sin(fi);
        circleY = centerY + this.m_fY * Math.sin(fi);// - R * Math.cos(fi);
    }

    constructor() {
        super();  // tady asi nep�i�azovat nic???

        this.m_fDMax = par_DMax_val
        this.m_fDMin = par_DMin_val;
        this.m_fWMax = par_WMax_val;   // tohle d�l� probl�m, mus�me pouze limitovat vstup!!!!!!!!!
        this.m_fWMin = par_WMin_val;
        this.m_fUMax = par_UMax_val;
        this.m_fUMin = par_UMin_val;
        this.m_fYMax = par_YMax_val;
        this.m_fYMin = par_YMin_val;

        this.m_fA0 = par_a0_val;  // PROBLEM!!!!
        this.m_fA1 = par_a1_val;
        this.m_fA2 = par_a2_val;
        this.m_fA3 = par_a3_val;  // nebylo tam
        this.m_fA4 = par_a4_val;  // nebylo tam
        this.m_fSd = par_Sd_val;
        this.m_fSu = par_Su_val;
        this.m_fdT = par_dT_val;
        console.log("GGG");
        console.log(this.m_fWMax, this.m_fWMin, this.m_fW);
    }

        deriv1(y1,y2) {

            return (y1 - y2) / this.m_fdT;
        }
  
        deriv2(y1, y2, y3) {
            return (deriv1(y1, y2) - deriv1(y2, y3)) / this.m_fdT;
        }
  /*  // je to n�kde pot�eba???
           deriv2() {
            let tmp = deriv2(this.m_aLast[0], this.m_aLast[1], this.m_aLast[2]);
            if (tmp > 1.0) 
            tmp = 1.0;
            if (tmp < -1.0)
            tmp = -1.0D;
            return tmp;
        }
        */
    draw() {
        c.clearRect(0, 0, 500, 500);
        this.drawLine();
        this.drawBall();
        this.drawSupport();
        this.drawTarget();
    }
    drawLine() {
        c.beginPath();
        c.moveTo(centerX + (-l * Math.cos(fi)), centerY + (-l * Math.sin(fi)));
        c.lineTo(centerX + (l * Math.cos(fi)), centerY + (l * Math.sin(fi)));
        c.stroke();
        
        c.strokeStyle = '#ff0000';
    }
    drawBall() {
        fi = this.m_fU * this.m_fSu / (this.m_fUMax - this.m_fUMin) * this.m_fSu / 2.0 * 0.7853981633974483;
        // g.drawOval(stred.x - 5 + (int)(this.m_fY * Math.cos(fi) - -5.0D * Math.sin(fi)), stred.y - 5 + (int)(this.m_fY * Math.sin(fi) + -5.0D * Math.cos(fi)), 10, 10);
        c.beginPath();
        c.arc(centerX + this.m_fY * Math.cos(fi) - (-5 * Math.sin(fi)), centerY - 5 + this.m_fY * Math.sin(fi) + (-5 * Math.cos(fi)),10,0,  Math.PI*2,false);  //bylo tu centerX - 5, 5 odend�no
        c.fillStyle = 'black';
        c.fill();
    }
    drawSupport() {
        //g.fillRect(stred.x + BaseX, stred.y + (int)(BaseX * Math.tan(fi)), 5, BaseHeight - (int)(BaseX * Math.tan(fi)));
        let BaseX = 0;
        let BaseHeight = 200;
        c.fillRect(centerX + BaseX-3, centerY + BaseX * Math.tan(fi), 6, BaseHeight - BaseX * Math.tan(fi));
    }
    drawTarget() {
      //  g.drawLine(centerX + this.m_fW * Math.cos(fi) - (-5 * Math.sin(fi)), centerY - 5 + this.m_fW * Math.sin(fi) + -(5 * Math.cos(fi)),
        //    centerX + this.m_fW * Math.cos(fi) - (-10 * Math.sin(fi)), stred.y - 5 + this.m_fW * Math.sin(fi) + (-10 * Math.cos(fi)));
        c.beginPath();
        c.moveTo(centerX + this.m_fW * Math.cos(fi) - (-20 * Math.sin(fi)), centerY - 5 + this.m_fW * Math.sin(fi) + -(20 * Math.cos(fi)));
        c.lineTo(centerX + this.m_fW * Math.cos(fi) - (-30 * Math.sin(fi)), centerY - 5 + this.m_fW * Math.sin(fi) + (-30 * Math.cos(fi)));
        c.stroke();
        c.strokeStyle = 'yellow';
    }
}

//engine a syst�m
let mainEngine = new Engine();
let systemKulicka = new Kulicka1D();
mainEngine.SetSystem(systemKulicka);
systemKulicka.draw();  // aby do�lo k prvn�mu vykreslen� p�ed startem... cel� asi d�t do n�jak� funkce init


//tla��tka pro volbu regul�toru
let P_button = document.querySelector("#P-cont");
let I_button = document.querySelector("#I-cont");
let PD_button = document.querySelector("#PD-cont");
let PI_button = document.querySelector("#PI-cont");
let PID_button = document.querySelector("#PID-cont");
let pol2_button = document.querySelector("#pol2-cont");
let pol3_button = document.querySelector("#pol3-cont");
let manual_button = document.querySelector("#manual-cont")
P_button.addEventListener('click', () => {
    let P = new PController();  
    P.setR0(par_PR0.val);
    mainEngine.SetController(P);
});
I_button.addEventListener('click', () => {
    let I = new IController();
    I.setTi(par_ITi.val)
    mainEngine.SetController(I);
});
PD_button.addEventListener('click', () => {
    let PD = new PDController();
    PD.setR0(par_PDR0.val);
    PD.setTd(par_PDTd.val);
    mainEngine.SetController(PD);
});
PI_button.addEventListener('click', () => {
    let PI = new PIController();
    PI.setR0(par_PIR0.val);
    PI.setTi(par_PITi.val);
    mainEngine.SetController(PI);
});
PID_button.addEventListener('click', () => {
    let PID = new PIDController();
    PID.setR0(par_PIDR0.val);
    PID.setTd(par_PIDTd.val);
    PID.setTi(par_PIDTi.val);
    mainEngine.SetController(PID);
});
pol2_button.addEventListener('click', () => { 
    let pol2 = new Pol2Controller();
    pol2.setUmax(par_Pol2Umax.val);
    pol2.setUmin(par_Pol2Umin.val);
    pol2.setHyst(par_Pol2Hyst.val);
    mainEngine.SetController(pol2);
});
pol3_button.addEventListener('click', () => {
    let pol3 = new Pol3Controller();  
    pol3.setHyst(par_Pol3Hyst.val);
    pol3.setUmax(par_Pol3Umax.val);
    pol3.setUmin(par_Pol3Umin.val);
    pol3.setNecit(par_Pol3Necit.val);
    mainEngine.SetController(pol3);
});
manual_button.addEventListener('click', () => {
    let MC = new manualController();
    mainEngine.SetController(MC); // v tu chv�li jde U na 0, asi spr�vn�...
});

// hlavni chod programu
function stop() {
    console.log("stopped");
    mainEngine.m_bPause = true;
    started = 0;
}
function start() {

    mainEngine.m_bPause = false;  // upravit, ale aby to te� fungovalo
    if (started != 1) {  // aby se nespustil hlavn� program n�kolikr�t, ur�it� upravit
        mainEngine.run();
    }
    started = 1;
}
var started = 0;

/*
 *   public void paint(Graphics g) {
    if (this.m_imgBackground != null)
      g.drawImage(this.m_imgBackground, 0, 0, getBackground(), null);
    Point stred = new Point(137, 107);
    double delka = 100.0D;
    double fi = this.m_fU * this.m_fSu / (this.m_fUMax - this.m_fUMin) * this.m_fSu / 2.0D * 0.7853981633974483D;
    g.setColor(Color.black);
    g.drawLine(stred.x + (int)(-delka * Math.cos(fi)), stred.y + (int)(-delka * Math.sin(fi)), stred.x + (int)(delka * Math.cos(fi)), stred.y + (int)(delka * Math.sin(fi)));
    g.drawOval(stred.x - 5 + (int)(this.m_fY * Math.cos(fi) - -5.0D * Math.sin(fi)), stred.y - 5 + (int)(this.m_fY * Math.sin(fi) + -5.0D * Math.cos(fi)), 10, 10);
    g.setColor(Color.red);
    g.drawLine(stred.x + (int)(this.m_fW * Math.cos(fi) - -5.0D * Math.sin(fi)), stred.y - 5 + (int)(this.m_fW * Math.sin(fi) + -5.0D * Math.cos(fi)), stred.x + (int)(this.m_fW * Math.cos(fi) - -10.0D * Math.sin(fi)), stred.y - 5 + (int)(this.m_fW * Math.sin(fi) + -10.0D * Math.cos(fi)));
    int BaseHeight = 50;
    int BaseX = -42;
    g.setColor(Color.black);
    g.fillRect(stred.x + BaseX, stred.y + (int)(BaseX * Math.tan(fi)), 5, BaseHeight - (int)(BaseX * Math.tan(fi)));
  }
}
*/