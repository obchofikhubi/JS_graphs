/*

<param name=Modell value="Vetrak">
   <param name=Su value=28.58>
   <param name=Sd value=0>
   <param name=a1 value=0.5>
   <param name=a2 value=0.25>
   <param name=a3 value=0.001>
   <param name=dT value=0.1>

   <param name=UMin value=0>
   <param name=UMax value=1>
   <param name=DMin value=-5>
   <param name=DMax value=5>
   <param name=WMin value=4>
   <param name=WMax value=20>


   <param name=PR0 value="0.72 0 1">
   <param name=ITi value="0.4 1 99">
   <param name=PIR0 value="0.65 0 1">
   <param name=PITi value="1.6 1 99">
   <param name=PDR0 value="0.57 0 1">
   <param name=PDTd value="0.097 0 10">
   <param name=PIDR0 value="0.86 0 1">
   <param name=PIDTi value="0.968 0.1 99">
   <param name=PIDTd value="0.116 0 10">
   <param name=Hyst2POL value="1.5 0 10">
   <param name=Umax2POL value="0.7 0 10">
   <param name=Umin2POL value="0.0 0 10">
   <param name=Hyst3POL value="0.5 0 10">
   <param name=Umax3POL value="0.7 0 10">
   <param name=Ustr3POL value="0.35 0 10">
   <param name=Umax3POL value="0.7 0 10">
   <param name=Necit3POL value="1.0 0 10">


this.m_fDMax = 20.0D;
this.m_fDMin = -20.0D;
this.m_fWMax = 20.0D;
this.m_fWMin = 0.0D;
this.m_fUMax = 0.7D;
this.m_fUMin = 0.0D;
this.m_fYMax = 20.0D;
this.m_fYMin = 0.0D;
*/




par_Su_val = 28.58;
par_Sd_val = 0;
par_a0_val = 0;   // POZOR, NEBYLO TO NIKDE, // 1 - statick� soustava, 0 - astatick� soustava
par_a1_val = 0.5;
par_a2_val = 0.25;
par_a3_val = 0.001;
par_a4_val = 0;
par_Astatic_val = true;
par_dT_val = 0.1;  // tady 0.1, jinde ani neudan�? u n�dr�e t�eba
par_DMin_val = -20;
par_DMax_val = 20;
par_WMin_val = 0;
par_WMax_val = 20;
par_UMin_val = 0;
par_UMax_val = 0.7;
par_YMin_val = 0;
par_YMax_val = 20;


par_PR0 = {
    val: 0.72,
    min: 0,
    max: 1
};
par_ITi = {
    val: 0.4,
    min: 1,
    max: 99
};
par_PIR0 = {
    val: 0.65,
    min: 0,
    max: 1
};
par_PITi = {
    val: 1.6,
    min: 1,
    max: 99
};
par_PDR0 = {
    val: 0.57,
    min: 0,
    max: 1
};
par_PDTd = {
    val: 0.097,
    min: 0,
    max: 10
};
par_PIDR0 = {
    val: 0.86,
    min: 0,
    max: 1
};
par_PIDTi = {
    val: 0.968,
    min: 0.1,
    max: 99
};
par_PIDTd = {
    val: 0.116,
    min: 0,
    max: 10
};
par_Pol2Hyst = {  // p�edtim bylo POL, upraveno aby se shodovalo s konstruktorem
    val: 1.5,
    min: 0,
    max: 10
};
par_Pol2Umax = {
    val: 0.7,
    min: 0,
    max: 10
};
par_Pol2Umin = {
    val: 0,
    min: 0,
    max: 10
};
par_Pol3Hyst = {
    val: 0.5,
    min: 0,
    max: 10
};
par_Pol3Necit = {
    val: 1,
    min: 0,
    max: 10
};
par_Pol3Umax = {
    val: 0.7,
    min: 0,
    max: 10
};
par_Pol3Ustr = {
    val: 0.35,
    min: 0,
    max: 10
};
par_Pol3Umin = {  // tohle pan Trnka nem�
    val: 0,
    min: 0,
    max: 10
};
//////////////////////////////////////////////////////////// n�kter� parametry u pana trnky v�bec nejsou!!!

// geometrie konkr�tn� �lohy

let centerX = 250;
let centerY = 250;
let circleX = 0;
let circleY = 0;
let l = 240;
let R = 15;
let fi = 0;

/////////////////////////////////////////////////////////////////////////////////////////

// canvas - svg


const canvas1 = document.getElementById('layer1');
const canvas2 = document.getElementById('layer2');
canvas1.width = 500;
canvas1.height = 500;
canvas2.width = 500;
canvas2.height = 500;  // ? neni zbytecne??

const c1 = canvas1.getContext('2d');
const c2 = canvas2.getContext('2d');

const backgroundImg = new Image(canvas1.width, canvas1.height);
backgroundImg.src = '../pictures/vetrak_on.gif';
backgroundImg.onload = function () {
    c1.drawImage(backgroundImg, 0, 0, canvas1.width, canvas1.height);
}




class Vetrak extends AbstractSystem {

  //  Image m_imgBackground = null;

   // Image[] m_imgMicek = new Image[3];

    m_nAnimNo = 0;

    constructor() {
        super();  // tady asi nep�i�azovat nic???

        this.m_fDMax = par_DMax_val
        this.m_fDMin = par_DMin_val;
        this.m_fWMax = par_WMax_val;   // tohle d�l� probl�m, mus�me pouze limitovat vstup!!!!!!!!!
        this.m_fWMin = par_WMin_val;
        this.m_fUMax = par_UMax_val;
        this.m_fUMin = par_UMin_val;
        this.m_fYMax = par_YMax_val;
        this.m_fYMin = par_YMin_val;

        this.m_fA0 = par_a0_val;
        this.m_fA1 = par_a1_val;
        this.m_fA2 = par_a2_val;
        this.m_fA3 = par_a3_val;
        this.m_fA4 = par_a4_val;
        this.m_fSd = par_Sd_val;
        this.m_fSu = par_Su_val;
        this.m_fdT = par_dT_val;
    }


    draw() {
        this.m_nAnimNo = (this.m_nAnimNo < 1) ? 2 : (this.m_nAnimNo - 1);  // MO�NOST 3 obr�zky m��ku, je zvl�tn� poskl�dan� po�ad�, kdy�tak p�ehodit
        //c2.clearRect(0, 0, 500, 500); p�ema�e upn�
        let nX = 120;
        let nY = 106;
    
        nY = nY -  Math.round(100.0 * (this.m_fY - this.m_fYMin) / (this.m_fYMax - this.m_fYMin));
        let ballImg = new Image(60, 60);
       // document.body.appendChild(ballImg);
            ballImg.src = `../pictures/vetrak${this.m_nAnimNo}.gif`;   //${myInt}   `````` ne apostrof!
            ballImg.onload = function () {
                c2.drawImage(ballImg, nX, nY, 60, 60);
                // document.body.ballImg.style.display = 'none';
               // document.getElementById("ballImg").style.display = 'none';    // nefunguje nic
               // document.body.removeChild(ballImg);
        }
        //document.body.ballImg.src='';
        // https://stackoverflow.com/questions/12187720/cant-draw-image-on-canvas-after-clearrect

        
        /*
    g.setColor(Color.blue);
    g.drawString("h: " + (Math.round(this.m_fY * 10.0D) / 10.0D), nX + 40, nY + 9);
    nX = 130;
    nY = 106 - (int)(100.0D * (this.m_fW - this.m_fWMin) / (this.m_fWMax - this.m_fWMin)) + 5;
    g.setColor(Color.magenta);
    g.drawOval(nX, nY, 10, 10);
    g.drawString("W: " + (Math.round(this.m_fW * 10.0D) / 10.0D), nX - 60, nY + 9);
    }*/

        
    }

}

//engine a syst�m
let mainEngine = new Engine();
let system = new Vetrak();
mainEngine.SetSystem(system);
system.draw();  // aby do�lo k prvn�mu vykreslen� p�ed startem... cel� asi d�t do n�jak� funkce init


// hlavni chod programu
function stop() {
    console.log("stopped");
    mainEngine.m_bPause = true;
    started = 0;
}
function start() {

    mainEngine.m_bPause = false;  // upravit, ale aby to te� fungovalo
    if (started != 1) {  // aby se nespustil hlavn� program n�kolikr�t, ur�it� upravit
        mainEngine.run();
    }
    started = 1;
}
var started = 0;

function animate() {
    animationId = window.requestAnimationFrame(animate);
    MAIN();
}

function MAIN() {
    //tady canvas
    system.draw();
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// pod t�mto pro v�echny �lohy stejn�, nem�nit!!!

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//tla��tka pro volbu regul�toru
let P_button = document.querySelector("#P-cont");
let I_button = document.querySelector("#I-cont");
let PD_button = document.querySelector("#PD-cont");
let PI_button = document.querySelector("#PI-cont");
let PID_button = document.querySelector("#PID-cont");
let pol2_button = document.querySelector("#pol2-cont");
let pol3_button = document.querySelector("#pol3-cont");
let manual_button = document.querySelector("#manual-cont")
P_button.addEventListener('click', () => {
    let P = new PController();
    P.setR0(par_PR0.val);
    mainEngine.SetController(P);
});
I_button.addEventListener('click', () => {
    let I = new IController();
    I.setTi(par_ITi.val)
    mainEngine.SetController(I);
});
PD_button.addEventListener('click', () => {
    let PD = new PDController();
    PD.setR0(par_PDR0.val);
    PD.setTd(par_PDTd.val);
    mainEngine.SetController(PD);
});
PI_button.addEventListener('click', () => {
    let PI = new PIController();
    PI.setR0(par_PIR0.val);
    PI.setTi(par_PITi.val);
    mainEngine.SetController(PI);
});
PID_button.addEventListener('click', () => {
    let PID = new PIDController();
    PID.setR0(par_PIDR0.val);
    PID.setTd(par_PIDTd.val);
    PID.setTi(par_PIDTi.val);
    mainEngine.SetController(PID);
});
pol2_button.addEventListener('click', () => {
    let pol2 = new Pol2Controller();
    pol2.setUmax(par_Pol2Umax.val);
    pol2.setUmin(par_Pol2Umin.val);
    pol2.setHyst(par_Pol2Hyst.val);
    mainEngine.SetController(pol2);
});
pol3_button.addEventListener('click', () => {
    let pol3 = new Pol3Controller();
    pol3.setHyst(par_Pol3Hyst.val);
    pol3.setUmax(par_Pol3Umax.val);
    pol3.setUmin(par_Pol3Umin.val);
    pol3.setNecit(par_Pol3Necit.val);
    mainEngine.SetController(pol3);
});
manual_button.addEventListener('click', () => {
    let MC = new manualController();
    mainEngine.SetController(MC); // v tu chv�li jde U na 0, asi spr�vn�...
});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

stopButton = document.querySelector("#stop-button");
stopButton.addEventListener('click', () => {
    stop();
});
mainButton = document.querySelector("#main-button");
mainButton.addEventListener('click', () => {
    animate();
    start();
});

confButton = document.querySelector("#conf-button");
confButton.addEventListener('click', () => {
    confirm();
})

const allParams = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "D", "W", "U"];  //lze pou��t taky mainEngine.allParams, nev�m co je efektivn�j�� ////"D", "W", "U",
const contParams = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "U"];  // U br�no pro manual jako parametr cont??


function confirm() {
    if (mainEngine.m_Controller != null) {
        console.log(mainEngine.m_System.m_fWMax);
        for (var i = 0; i < allParams.length; i++) {

            let userVal = document.getElementById(allParams[i] + "-user").value;

            if (userVal != "") {  // neni prazdny vstup, v�echny by se m�li p�edtim vyresetovat kdy� se d�v� display.none
                document.getElementById(allParams[i] + "-val").innerHTML = userVal;

                if (allParams[i] === "D") {
                    mainEngine.SetD(parseInt(userVal));
                }
                else if (allParams[i] === "W") {  // CHCEME LIMITOVAT JEN VSTUP, ALE NE VYPO��TAN� W
                    userVal = limit(userVal, par_WMin_val, par_WMax_val);
                    console.log(userVal);
                    mainEngine.SetW(parseInt(userVal));  // engine u� dosad� W do syst�mu i regul�toru limitovan�, pak n�jak sjednotit, n�kde jsou 2x limitace
                }
                else if (allParams[i] === "U") {
                    mainEngine.m_System.setU(parseInt(userVal));
                    mainEngine.m_Controller.setU(parseInt(userVal));  // rozd�len� kv�li manu�ln�mu ��zen�, jin� regul�tory nemaj� setter setU!
                }
                else {
                    let name = mainEngine.m_Controller.constructor.name; // t�eba PIController!!, nutno ode��st controller??
                    let wtf = name.search("Controller");
                    let cutted = name.slice(0, wtf);  // z�stane n�m jen n�zev regul�toru ( P,PI,Pol2,Pol3 
                    let finalName = "par_" + cutted + allParams[i];
                    let val = parseInt(userVal);
                    let minVal = window[finalName]["min"]; // asi ud�lat n�jakou global class a� nevstupujeme do window pro parametry???
                    let maxVal = window[finalName]["max"];

                    let limitedVal = limit(val, minVal, maxVal);  // vol� limit z Controllers (je tam jako function)
                    mainEngine.m_Controller["set" + allParams[i]](limitedVal); //vol� setter
                }
            }
        }
    }
    else {
        console.log("Controller not set!");
    }
    console.log(mainEngine);
}