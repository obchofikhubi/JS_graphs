
/*
var baseInput = document.getElementById('inputChart1').getContext('2d');

const chart = new Chart(baseInput, {
    type: 'line',
    data: {
        datasets: [{
            data: [{ x: 0, y: 0 }, { x: 10, y: 10 }, { x: 20, y: 22 }, { x: 100, y: 100 }],
            fill: false,
            label: 'Zadejte hodnotu W',  // tady lze d�t dal�� data, nap� ak�n� hodnotu
        }]
    },
    options: {
        onClick: (e) => {
            console.log("WWWW");
            //const canvasPosition = Chart.helpers.getRelativePosition(e, chart);

            // Substitute the appropriate scale IDs
            //const dataX = chart.scales.x.getValueForPixel(canvasPosition.x);
            //const dataY = chart.scales.y.getValueForPixel(canvasPosition.y);
        }
    }
});
*/
/*
var graf = new Chart(baseInput, {
    type: 'scatter',
    data: {
        datasets: [{
            data: [{ x: 0, y: 0 }],
            fill: false,
            label: 'Zadejte hodnotu W',  // tady lze d�t dal�� data, nap� ak�n� hodnotu
        }]
    },
    options: {
        events: ['click'],
        onClick: (e) => {
            console.log("hhhh");
            const canvasPosition = Chart.helpers.getRelativePosition(e, graf);
            
            // Substitute the appropriate scale IDs
            
            const dataX = graf.scales.xAxes.getValueForPixel(canvasPosition.x);
            const dataY = graf.scales.yXes.getValueForPixel(canvasPosition.y);
            console.log(dataX, dataY);
        }


*/
        /*
        ,

        scales: {

            yAxes: [{    //pokud je jen y, tak nefunguje...
                ticks: {
                    beginAtZero: true,
                    max: 150,
                    min: -150
                }
            }],
            xAxes: [{
                ticks: {
                    beginAtZero: true,
                    max: 200,
                    min: 0
                }
            }]

        }
       
    }
});
 */


const datasets = [{
    label: '# of Votes',
    data: [12, 19, 3, 5, 2, 3],
    backgroundColor: [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
        'rgba(255, 159, 64, 0.2)'
    ],
    borderColor: [
        'rgba(255,99,132,1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(153, 102, 255, 1)',
        'rgba(255, 159, 64, 1)'
    ],
    borderWidth: 1
}]

const ctx = document.getElementById("myChart").getContext('2d');
const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets
    },
    options: {
        scales: {
            /*
            yAxes: [{    //pokud je jen y, tak nefunguje..., celkov� to h�zi chyby
                ticks: {
                    beginAtZero: true,
                    max: 150,
                    min: -150
                }
            }],
            xAxes: [{
                ticks: {
                    beginAtZero: true,
                    max: 200,
                    min: 0
                }
            }]
            */
            y: {
                suggestedMin: 50,
                suggestedMax: 100
            }
        },
        onClick(e) {  // NEFUNGUJE VUBEC
            console.log("JSME TU!");
            const activePoints = myChart.getElementsAtEventForMode(e, 'nearest', {
                intersect: true
            }, false)
            const [{
                index
            }] = activePoints;
            console.log(datasets[0].data[index]);
        }
    }
});