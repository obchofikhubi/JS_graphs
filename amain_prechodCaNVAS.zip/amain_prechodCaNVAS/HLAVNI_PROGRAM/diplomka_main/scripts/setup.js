// hlavni chod programu
function stop() {
    console.log("stopped");
    mainEngine.m_bPause = true;
    started = 0;
}
function start() {

    mainEngine.m_bPause = false;  // upravit, ale aby to te� fungovalo
    if (started != 1) {  // aby se nespustil hlavn� program n�kolikr�t, ur�it� upravit
        mainEngine.run();
    }
    started = 1;
}
var started = 0;

function animate() {
    animationId = window.requestAnimationFrame(animate);
    MAIN();
}

function MAIN() {
    //tady canvas
    system.draw();
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// pod t�mto pro v�echny �lohy stejn�, nem�nit!!!

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//tla��tka pro volbu regul�toru
let P_button = document.querySelector("#P-cont");
let I_button = document.querySelector("#I-cont");
let PD_button = document.querySelector("#PD-cont");
let PI_button = document.querySelector("#PI-cont");
let PID_button = document.querySelector("#PID-cont");
let pol2_button = document.querySelector("#pol2-cont");
let pol3_button = document.querySelector("#pol3-cont");
let manual_button = document.querySelector("#manual-cont")

const allParams = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "D", "W", "U"];  //lze pou��t taky mainEngine.allParams, nev�m co je efektivn�j�� ////"D", "W", "U",
const contParams = ["R0", "Ti", "Td", "Hyst", "Umin", "Ustr", "Umax", "Necit", "U"];  // U br�no pro manual jako parametr cont??

P_button.addEventListener('click', () => {
    let P = new PController();
    P.setR0(par_PR0.val);
    mainEngine.SetController(P);
});
I_button.addEventListener('click', () => {
    let I = new IController();
    I.setTi(par_ITi.val)
    mainEngine.SetController(I);
});
PD_button.addEventListener('click', () => {
    let PD = new PDController();
    PD.setR0(par_PDR0.val);
    PD.setTd(par_PDTd.val);
    mainEngine.SetController(PD);
});
PI_button.addEventListener('click', () => {
    let PI = new PIController();
    PI.setR0(par_PIR0.val);
    PI.setTi(par_PITi.val);
    mainEngine.SetController(PI);
});
PID_button.addEventListener('click', () => {
    let PID = new PIDController();
    PID.setR0(par_PIDR0.val);
    PID.setTd(par_PIDTd.val);
    PID.setTi(par_PIDTi.val);
    mainEngine.SetController(PID);
});
pol2_button.addEventListener('click', () => {
    let pol2 = new Pol2Controller();
    pol2.setUmax(par_Pol2Umax.val);
    pol2.setUmin(par_Pol2Umin.val);
    pol2.setHyst(par_Pol2Hyst.val);
    mainEngine.SetController(pol2);
});
pol3_button.addEventListener('click', () => {
    let pol3 = new Pol3Controller();
    pol3.setHyst(par_Pol3Hyst.val);
    pol3.setUmax(par_Pol3Umax.val);
    pol3.setUmin(par_Pol3Umin.val);
    pol3.setNecit(par_Pol3Necit.val);
    mainEngine.SetController(pol3);
});
manual_button.addEventListener('click', () => {
    let MC = new manualController();
    mainEngine.SetController(MC); // v tu chv�li jde U na 0, asi spr�vn�...
});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

stopButton = document.querySelector("#stop-button");
stopButton.addEventListener('click', () => {
    stop();
});
mainButton = document.querySelector("#main-button");
mainButton.addEventListener('click', () => {
    animate();
    start();
});

confButton = document.querySelector("#conf-button");
confButton.addEventListener('click', () => {
    confirm();
})




function confirm() {
    if (mainEngine.m_Controller != null) {
        console.log(mainEngine.m_System.m_fWMax);
        for (var i = 0; i < allParams.length; i++) {

            let userVal = document.getElementById(allParams[i] + "-user").value;

            if (userVal != "") {  // neni prazdny vstup, v�echny by se m�li p�edtim vyresetovat kdy� se d�v� display.none, NERESETOVAT!!!,  parametry a� se daj� porovn�vat a z�stavaj�, reset jen po RESET
                document.getElementById(allParams[i] + "-val").innerHTML = userVal;

                if (allParams[i] === "D") {
                    mainEngine.SetD(parseInt(userVal));
                }
                else if (allParams[i] === "W") {  // CHCEME LIMITOVAT JEN VSTUP, ALE NE VYPO��TAN� W
                    userVal = limit(userVal, par_WMin_val, par_WMax_val);
                    console.log(userVal);
                    mainEngine.SetW(parseInt(userVal));  // engine u� dosad� W do syst�mu i regul�toru limitovan�, pak n�jak sjednotit, n�kde jsou 2x limitace
                }
                else if (allParams[i] === "U") {
                    mainEngine.m_System.setU(parseInt(userVal));
                    mainEngine.m_Controller.setU(parseInt(userVal));  // rozd�len� kv�li manu�ln�mu ��zen�, jin� regul�tory nemaj� setter setU!
                }
                else {
                    let name = mainEngine.m_Controller.constructor.name; // t�eba PIController!!, nutno ode��st controller??
                    let wtf = name.search("Controller"); //wtf = word to find
                    let cutted = name.slice(0, wtf);  // z�stane n�m jen n�zev regul�toru ( P,PI,Pol2,Pol3 
                    let finalName = "par_" + cutted + allParams[i];
                    let val = parseInt(userVal);
                    let minVal = window[finalName]["min"]; // asi ud�lat n�jakou global class a� nevstupujeme do window pro parametry???
                    let maxVal = window[finalName]["max"];

                    let limitedVal = limit(val, minVal, maxVal);  // vol� limit z Controllers (je tam jako function)
                    mainEngine.m_Controller["set" + allParams[i]](limitedVal); //vol� setter
                }
            }
        }
    }
    else {
        setDefaultCont();
        console.log("Default cont set!");
    }
    console.log(mainEngine);
}

function setDefaultCont() {
    let defP = new PController();
    defP.setR0(par_PR0.val);
    mainEngine.SetController(defP);
}
confirm();