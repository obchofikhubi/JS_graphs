par_Su_val = 1.6;
par_Sd_val = 0;
par_a0_val = 0;   // POZOR, NEBYLO TO NIKDE, // 1 - statick� soustava, 0 - astatick� soustava
par_a1_val = 0;
par_a2_val = 1;
par_a3_val = 0;
par_a4_val = 0;
par_Astatic_val = true;
par_dT_val = 0.3;
par_DMin_val = 0;
par_DMax_val = 100;
par_WMin_val = 0;
par_WMax_val = 60;
par_UMin_val = -100;
par_UMax_val = 100;
par_YMin_val = 0;
par_YMax_val = 60;


par_PR0 = {
    val: 0.05,
    min: 0,
    max: 5
};
par_ITi = {
    val: 20000,
    min: 1,
    max: 50000
};
par_PIR0 = {
    val: 0.05,
    min: 0,
    max: 1
};
par_PITi = {
    val: 5,
    min: 1,
    max: 99
};
par_PDR0 = {
    val: 0.05,
    min: 0,
    max: 5
};
par_PDTd = {
    val: 7,
    min: 0,
    max: 10
};
par_PIDR0 = {
    val: 0.05,
    min: 0,
    max: 2
};
par_PIDTi = {
    val: 60,
    min: 1,
    max: 99
};
par_PIDTd = {
    val: 14,
    min: 0,
    max: 50
};
par_Pol2Hyst = {  // p�edtim bylo POL, upraveno aby se shodovalo s konstruktorem
    val: 10,
    min: 1,
    max: 100
};
par_Pol2Umax = {
    val: 0.5,
    min: -5,
    max: 5
};
par_Pol2Umin = {
    val: -0.5,
    min: -5,
    max: 5
};
par_Pol3Hyst = {
    val: 10,
    min: 1,
    max: 100
};
par_Pol3Necit = {
    val: 30,
    min: 0,
    max: 50
};
par_Pol3Umax = {
    val: 0.5,
    min: -5,
    max: 5
};
par_Pol3Ustr = {
    val: 0,
    min: -5,
    max: 5
};
par_Pol3Umin = {
    val: -0.5,
    min: -5,
    max: 5
};


// geometrie konkr�tn� �lohy

let centerX = 250;
let centerY = 250;
let circleX = 0;
let circleY = 0;
let l = 240;
let R = 15;
let fi = 0;

/////////////////////////////////////////////////////////////////////////////////////////

// canvas - svg


const canvas = document.querySelector('canvas');
canvas.width = 500;
canvas.height = 500;
const c = canvas.getContext('2d')

c.fillStyle = "blue";
c.fillRect(0, 0, canvas.width, canvas.height);


const linka = document.querySelector("#linka1");
const kruh = document.querySelector("#kruh");

function updateLine(uhelDeg) {

    anime({
        targets: linka,
        rotate: uhelDeg,
        transformOrigin: ['50% 30%', '50% 30%']  // p�ijde mi to trochu posunut� doprava!!!, NUTNO DOPOCITAT... 50,50 je asi �patn�, bran� od rohu svg??
    });
}


function updateCircle(x, y) {

    anime({
        targets: kruh,
        translateX: x - 250,
        translateY: y - 84,
    });
}

function radians_to_degrees(radians) {
    var pi = Math.PI;
    return radians * (180 / pi);
}



class Kulicka1D extends AbstractSystem {  // upravit

    drawSWG() {
        let fi_deg = radians_to_degrees(fi);
        updateLine(fi_deg);
        updateCircle(circleX, circleY - 165);

        //test
        if (this.m_fU > this.m_fUMax) {        ///////////////////////////////////////////////// nen� tu tahle limitace zbyte�n�??
            this.m_fU = this.m_fUMax;
        }
        if (this.m_fU < this.m_fUMin) {  // antiwindup, nebo n�co jin�ho?
            this.m_fU = this.m_fUMin;
        }
        fi = this.m_fU * this.m_fSu / (this.m_fUMax - this.m_fUMin) * this.m_fSu / 2.0 * 0.7853981633974483;
        // takhle to je podle pana Trnky, nev�m pro� ode�t�tat R...
        //circleX = centerX - R + this.m_fY * Math.cos(fi) + R * Math.sin(fi);
        //circleY = centerY - R + this.m_fY * Math.sin(fi) - R * Math.cos(fi);
        circleX = centerX + this.m_fY * Math.cos(fi); // + R * Math.sin(fi);
        circleY = centerY + this.m_fY * Math.sin(fi);// - R * Math.cos(fi);
    }

    constructor() {
        super();  // tady asi nep�i�azovat nic???

        this.m_fDMax = par_DMax_val
        this.m_fDMin = par_DMin_val;
        this.m_fWMax = par_WMax_val;   // tohle d�l� probl�m, mus�me pouze limitovat vstup!!!!!!!!!
        this.m_fWMin = par_WMin_val;
        this.m_fUMax = par_UMax_val;
        this.m_fUMin = par_UMin_val;
        this.m_fYMax = par_YMax_val;
        this.m_fYMin = par_YMin_val;

        this.m_fA0 = par_a0_val;  // PROBLEM!!!!
        this.m_fA1 = par_a1_val;
        this.m_fA2 = par_a2_val;
        this.m_fA3 = par_a3_val;  // nebylo tam
        this.m_fA4 = par_a4_val;  // nebylo tam
        this.m_fSd = par_Sd_val;
        this.m_fSu = par_Su_val;
        this.m_fdT = par_dT_val;
        console.log("GGG");
        console.log(this.m_fWMax, this.m_fWMin, this.m_fW);
    }

    deriv1(y1, y2) {

        return (y1 - y2) / this.m_fdT;
    }

    deriv2(y1, y2, y3) {
        return (deriv1(y1, y2) - deriv1(y2, y3)) / this.m_fdT;
    }
    /*  // je to n�kde pot�eba???
             deriv2() {
              let tmp = deriv2(this.m_aLast[0], this.m_aLast[1], this.m_aLast[2]);
              if (tmp > 1.0) 
              tmp = 1.0;
              if (tmp < -1.0)
              tmp = -1.0D;
              return tmp;
          }
          */
    draw() {
        c.clearRect(0, 0, 500, 500);
        this.drawLine();
        this.drawBall();
        this.drawSupport();
        this.drawTarget();


        this.drawSWG();
        console.log(circleX, circleY);  // nevim pro� je kruh na za��tku pry�...!
    }
    drawLine() {
        c.beginPath();
        c.moveTo(centerX + (-l * Math.cos(fi)), centerY + (-l * Math.sin(fi)));
        c.lineTo(centerX + (l * Math.cos(fi)), centerY + (l * Math.sin(fi)));
        c.stroke();

        c.strokeStyle = '#ff0000';
    }
    drawBall() {
        fi = this.m_fU * this.m_fSu / (this.m_fUMax - this.m_fUMin) * this.m_fSu / 2.0 * 0.7853981633974483;
        // g.drawOval(stred.x - 5 + (int)(this.m_fY * Math.cos(fi) - -5.0D * Math.sin(fi)), stred.y - 5 + (int)(this.m_fY * Math.sin(fi) + -5.0D * Math.cos(fi)), 10, 10);
        c.beginPath();
        c.arc(centerX + this.m_fY * Math.cos(fi) - (-5 * Math.sin(fi)), centerY - 5 + this.m_fY * Math.sin(fi) + (-5 * Math.cos(fi)), 10, 0, Math.PI * 2, false);  //bylo tu centerX - 5, 5 odend�no
        c.fillStyle = 'black';
        c.fill();
    }
    drawSupport() {
        //g.fillRect(stred.x + BaseX, stred.y + (int)(BaseX * Math.tan(fi)), 5, BaseHeight - (int)(BaseX * Math.tan(fi)));
        let BaseX = 0;
        let BaseHeight = 200;
        c.fillRect(centerX + BaseX - 3, centerY + BaseX * Math.tan(fi), 6, BaseHeight - BaseX * Math.tan(fi));
    }
    drawTarget() {
        //  g.drawLine(centerX + this.m_fW * Math.cos(fi) - (-5 * Math.sin(fi)), centerY - 5 + this.m_fW * Math.sin(fi) + -(5 * Math.cos(fi)),
        //    centerX + this.m_fW * Math.cos(fi) - (-10 * Math.sin(fi)), stred.y - 5 + this.m_fW * Math.sin(fi) + (-10 * Math.cos(fi)));
        c.beginPath();
        c.moveTo(centerX + this.m_fW * Math.cos(fi) - (-20 * Math.sin(fi)), centerY - 5 + this.m_fW * Math.sin(fi) + -(20 * Math.cos(fi)));
        c.lineTo(centerX + this.m_fW * Math.cos(fi) - (-30 * Math.sin(fi)), centerY - 5 + this.m_fW * Math.sin(fi) + (-30 * Math.cos(fi)));
        c.stroke();
        c.strokeStyle = 'yellow';
    }
}

//engine a syst�m
let mainEngine = new Engine();
let system = new Kulicka1D();
mainEngine.SetSystem(system);
system.draw();  // aby do�lo k prvn�mu vykreslen� p�ed startem... cel� asi d�t do n�jak� funkce init
console.log(circleX, circleY);
