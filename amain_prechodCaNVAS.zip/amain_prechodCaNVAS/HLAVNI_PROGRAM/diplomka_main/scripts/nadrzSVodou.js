/*
< !--Parametry soustavy-- >
    <param name=Modell value="Tronic">
        <!--
        <param name=Su value=23>
        <param name=Sd value=-23>
        <param name=a1 value=8000>
-->
        <param name=Su value=800>
        <param name=Sd value=-800>
        <param name=a1 value=8000>
        <param name=a2 value=0>

        <param name=DMin value=0>
        <param name=DMax value=30>
        <param name=WMin value=0>
        <param name=WMax value=140>


        <!-- Parametry regulatoru -->
        <param name=PR0 value="1 0 100">
            <param name=ITd value="5 1 99">
                <param name=PIR0 value="2 0 100">
                    <param name=PITi value="5 1 99">
                        <param name=PDR0 value="1 0 10">
                            <param name=PDTd value="5 0 30">
                                <param name=PIDR0 value="3 0 10">
                                    <param name=PIDTi value="5 1 99">
                                        <param name=PIDTd value="1 0 10">
                                            <param name=Hyst2POL value="10 1 140">
                                                <param name=Umax2POL value="40 0 50">
                                                    <param name=Hyst3POL value="10 1 140">
                                                        <param name=Umax3POL value="40 0 50">

  this.m_fYMax = 60.0D;
    this.m_fYMin = 0.0D;
    this.m_fWMax = 60.0D;
    this.m_fWMin = 0.0D;
    this.m_fDMin = 0.0D;
    this.m_fDMax = 100.0D;
    this.m_fUMin = -100.0D;
    this.m_fUMax = 100.0D;
 */


par_Su_val = 800;
par_Sd_val = -800;
par_a0_val = 0;   // POZOR, NEBYLO TO NIKDE, // 1 - statick� soustava, 0 - astatick� soustava
par_a1_val = 8000;
par_a2_val = 0;
par_a3_val = 0;
par_a4_val = 0;
par_Astatic_val = true;
par_dT_val = 0.3;
par_DMin_val = 0;
par_DMax_val = 100;
par_WMin_val = 0;
par_WMax_val = 60;
par_UMin_val = -100;
par_UMax_val = 100;
par_YMin_val = 0;
par_YMax_val = 60;  // asi stejn� jako W... tady konkr�tn� nem��e p�et�ct!!!
// upravit podle na�eho m���tka????


par_PR0 = {
    val: 1,
    min: 0,
    max: 100
};
par_ITi = {
    val: 5,
    min: 1,
    max: 99
};
par_PIR0 = {
    val: 2,
    min: 0,
    max: 100
};
par_PITi = {
    val: 5,
    min: 1,
    max: 99
};
par_PDR0 = {
    val: 1,
    min: 0,
    max: 10
};
par_PDTd = {
    val: 5,
    min: 0,
    max: 30
};
par_PIDR0 = {
    val: 3,
    min: 0,
    max: 10
};
par_PIDTi = {
    val: 5,
    min: 1,
    max: 99
};
par_PIDTd = {
    val: 1,
    min: 0,
    max: 10
};
par_Pol2Hyst = {  // p�edtim bylo POL, upraveno aby se shodovalo s konstruktorem
    val: 10,
    min: 1,
    max: 140
};
par_Pol2Umax = {
    val: 40,
    min: 0,
    max: 50
};
par_Pol2Umin = {  // U PANA TRNKY NERESENO
    val: -0.5,
    min: -5,
    max: 5
};
par_Pol3Hyst = {
    val: 10,
    min: 1,
    max: 140
};
par_Pol3Necit = {  // U PANA TRNKY NERESENO
    val: 30,
    min: 0,
    max: 50
};
par_Pol3Umax = {
    val: 40,
    min: 0,
    max: 50
};
par_Pol3Ustr = {  // U PANA TRNKY NERESENO
    val: 0,
    min: -5,
    max: 5
};
par_Pol3Umin = {  // U PANA TRNKY NERESENO
    val: -0.5,
    min: -5,
    max: 5
};
//////////////////////////////////////////////////////////// n�kter� parametry u pana trnky v�bec nejsou!!!

// geometrie konkr�tn� �lohy

const canvas1 = document.getElementById('layer1');
const canvas2 = document.getElementById('layer2');
canvas1.width = 400; 
canvas1.height = 400;
canvas2.width = 400;
canvas2.height = 400;  // ? neni zbytecne??

const c1 = canvas1.getContext('2d');
const c2 = canvas2.getContext('2d');

const backgroundImg = new Image(canvas1.width, canvas1.height);  // nebo opa�n�?
backgroundImg.src = '../pictures/tronic.gif';
backgroundImg.onload = function () {  // mo�n� n�jak p�epsat??
    c1.drawImage(backgroundImg, 0, 0, canvas1.width, canvas1.height);
}


class WaterTank extends AbstractSystem {

    constructor() {
        super();  // tady asi nep�i�azovat nic???

        this.m_fDMax = par_DMax_val
        this.m_fDMin = par_DMin_val;
        this.m_fWMax = par_WMax_val;   // tohle d�l� probl�m, mus�me pouze limitovat vstup!!!!!!!!!
        this.m_fWMin = par_WMin_val;
        this.m_fUMax = par_UMax_val;
        this.m_fUMin = par_UMin_val;
        this.m_fYMax = par_YMax_val;
        this.m_fYMin = par_YMin_val;

        this.m_fA0 = par_a0_val;
        this.m_fA1 = par_a1_val;
        this.m_fA2 = par_a2_val;
        this.m_fA3 = par_a3_val;
        this.m_fA4 = par_a4_val;
        this.m_fSd = par_Sd_val;
        this.m_fSu = par_Su_val;
        this.m_fdT = par_dT_val;
        console.log("GGG");
        console.log(this.m_fWMax, this.m_fWMin, this.m_fW);
    }

    drawD() {
        c2.beginPath();
        c2.arc(75, 270, 8, 0, Math.PI * 2, false);  //bylo tu centerX - 5, 5 odend�no
        c2.fill();
         //drawOdtokD
    }
    drawU2() {
        c2.beginPath();
        c2.arc(402, 420, 8, 0, Math.PI * 2, false);  //bylo tu centerX - 5, 5 odend�no
        c2.fill();
         //drawOdtok2
    }
    drawU1() {
        c2.beginPath();
        c2.arc(91, 420, 8, 0, Math.PI * 2, false);  //bylo tu centerX - 5, 5 odend�no
        c2.fill();

        //drawOdtok1
    }

    draw() {
        console.log(mainEngine.m_System, mainEngine.m_Controller)
        c2.clearRect(0, 0, 400, 400);
        c2.font = "20px Arial";
        c2.fillStyle = 'red';
        if (this.m_fD > 0.0) {
            this.drawD();
            c2.fillText("D = " + system.m_fD, 65, 230);
        }
       
        if (this.m_fU <= 0.0) {
            c2.fillText("U2 = 0", 280, 270);
            if (this.m_fU != 0.0) {
                this.drawU1();
                c2.fillText("U1 = "+ (system.m_fU *(-1)).toFixed(2), 100, 370);
               
            } else {
                c2.fillText("U1 = 0", 100, 370);
            }
        }

        else {
            c2.fillText("U1 = 0", 100, 370);  
            c2.fillText("U2 = " + system.m_fU.toFixed(2), 280, 270);  // U2 je napravo
            this.drawU2();
        }
        
        
        if (this.m_fY >= 0 && this.m_fY <= 200) { 
            let ypos = Math.round(this.m_fY); // pro� n�sobit 2??? - tady bylo this.m_fY * 2
            c2.fillStyle = 'blue';
            c2.fillRect(151, 308 - ypos, 110, ypos);
            c2.fillText("Y = " + system.m_fY.toFixed(2), 160, 280 - ypos);
        } else {
            //g.setColor(Color.blue);
            //g.drawString("y = " + Math.round(this.m_fY), 103, 20);
        }
        
        if (this.m_fW >= 0 && this.m_fW <= 140) {  // tohle je �erven� linka
            let ypos =  Math.round(this.m_fW);// bylo tu 2L ???   // bylo tu W * 2, stejn� jako y nadtim, nevim d�vod
            c2.beginPath();
            c2.moveTo(150,310-ypos);
            c2.lineTo(260, 310 - ypos);
            c2.strokeStyle = '#ff0000';
            c2.stroke();
        }        // x - 188(139-width), y - 286
    }

}

//engine a syst�m
let mainEngine = new Engine();
let system = new WaterTank();
mainEngine.SetSystem(system);
system.draw();  // aby do�lo k prvn�mu vykreslen� p�ed startem... cel� asi d�t do n�jak� funkce init



