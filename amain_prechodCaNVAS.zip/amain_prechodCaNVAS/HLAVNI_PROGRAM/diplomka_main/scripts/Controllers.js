    /*
 * interface Controller {
  void setY(float paramFloat);

  void setW(float paramFloat);

  float getU();

  void Reset();

  void setdT(float paramFloat);
}
*/


function limit(what, from, to) {  // stejn� jako v syst�mu, vyu�ijeme na limitov�n� u setter� k regul�tor�m?? /// asi m��eme limitovat p��mo ve funkci CONFIRM na z�klad� regul�tor�???
    console.log(what);
    what = (what < from) ? from : ((what > to) ? to : what);
    return what; 
}


class manualController extends AbstractController {  // mo�n� bez extends?
    m_fU = 0.0;  

    array_of_params = ["U"];

    Reset() {
        super.Reset();
    }
    getU() {
        return this.m_fU;
    }
    setU(Value) {  // kde to limitujeme???
        this.m_fU = limit(Value, par_UMin_val, par_UMax_val); 
    }

    /*class ManualController extends AbstractController {
  float m_fValue = 0.0F;

  public void Reset() {
    super.Reset();
    this.m_fValue = 0.0F;
  }

  public void setValue(float Value) {
    this.m_fValue = Value;
  }

  public float getU() {
    return this.m_fValue;
  }
}

*/
}

class PController extends AbstractController {
    m_fR0 = 0.0;
    array_of_params = ["R0"];

    Reset() {
        super.Reset();
        this.m_fR0 = 0.0;
    }

    setR0(R0) {
        this.m_fR0 = R0;  
    }

    getU() {
       
        return this.m_fR0 * (this.m_fW - this.m_fY);
    }
    constructor() {  //chceme ho nebo ne??? pouze TEST!!!!
        super();
        this.Reset();
    }
    
    
}
//////////////////////////////////////////////////////
class IController extends AbstractController {
    m_fTi = 9999.0;

    m_fSuma = 0.0;

    array_of_params = ["Ti"];

    Reset() {
        super.Reset();
        this.m_fTi = 9999.0;
        this.m_fSuma = 0.0;
    }
    
    setTi(Ti) {
        this.m_fTi = Ti;
        console.log("Ti is set in I controller.");
    }

    getU() {
        let fe = this.m_fW - this.m_fY;
        this.m_fSuma += fe * this.m_fdT;
        return 1.0 / this.m_fTi * this.m_fSuma;
    }
}
/////////////////////////////////////////////////////////
class PIController extends PController {
    m_fTi = 9999.0;

    m_fSuma = 0.0;

    array_of_params = ["R0","Ti"];

    Reset() {
        super.Reset();
        this.m_fTi = 9999.0;
        this.m_fSuma = 0.0;
    }
    
    setTi(Ti) {
        this.m_fTi = Ti;
        console.log("Ti is set in PI controller.");
    }

    getU() {
        let fe = this.m_fW - this.m_fY;  
        this.m_fSuma += fe * this.m_fdT;
        return this.m_fR0 * (fe + 1.0 / this.m_fTi * this.m_fSuma);
    }
}
/////////////////////////////////////////////////////////////
class PDController extends PController {
    m_fTd = 0.0;

    m_fLastE = 0.0;

    array_of_params = ["R0","Td"];

    Reset() {
        super.Reset();
        this.m_fTd = 0.0;
        this.m_fLastE = 0.0;
    }

    setTd(Td) {
        this.m_fTd = Td;
        console.log("Td is set in PD controller.");
    }

    getU() {
        let fe = this.m_fW - this.m_fY;
        let fCurVal = this.m_fR0 * (fe + this.m_fTd * (fe - this.m_fLastE) / this.m_fdT);
        this.m_fLastE = fe;
       // console.log("GOMG");
        //console.log(fCurVal);
        return fCurVal;
     
    }
}
///////////////////////////////////////////////////////////////////
class PIDController extends PIController {
    m_fTd = 0.0;

    m_fLastE = 0.0;

    array_of_params = ["R0","Ti","Td"];

    Reset() {
        super.Reset();
        this.m_fTd = 0.0;
        this.m_fLastE = 0.0;
    }

    setTd(Td) {
        this.m_fTd = Td;
        console.log("Td is set in PID controller.");
    }

    getU() {
        let fe = this.m_fW - this.m_fY;
        this.m_fSuma += fe * this.m_fdT;
        let fCurVal = this.m_fR0 * (fe + 1.0 / this.m_fTi * this.m_fSuma + this.m_fTd * (fe - this.m_fLastE) / this.m_fdT);
        this.m_fLastE = fe;
        return fCurVal;
    }
}
/////////////////////////////////////////////////////////
class Pol2Controller extends AbstractController {
    m_fHyst = 0.0; //float

    U_min = 100;  // asi cosi ode m�, smazat???

    m_fUmax = 0.0;  //float

    m_fUmin = 0.0;  //float

    m_OutputControll = 0;  //int

    array_of_params = ["Umin", "Umax", "Hyst"];

    Reset() {
        super.Reset();
        this.m_fHyst = 0.0;
        this.m_fUmax = 0.0;
        this.m_fUmin = 0.0;
        this.m_OutputControll = 0;
    }

    

    setY(Y) {
        this.m_fY = Y;
        if (this.m_fY >= parseFloat(this.m_fW) + parseFloat(this.m_fHyst))
            this.m_OutputControll = -1;
        if (this.m_fY < parseFloat(this.m_fW) - parseFloat(this.m_fHyst))
            this.m_OutputControll = 1;
    }

    setW(W) {
        this.m_fW = W;
        this.setY(this.m_fY);  //nelze pou��t m_fY????
    }

    setHyst(Value) {
        this.m_fHyst = Value;
        console.log("Hyst is set in 2pol controller.");
    }

    setUmax(Value) {
        this.m_fUmax = Value;
        console.log("Umax is set in 2pol controller.");
    }

    setUmin(Value) {
        this.m_fUmin = Value;
        console.log("Umin is set in 2pol controller.");
    }

    getU() {
        if (this.m_OutputControll > 0)
            return this.m_fUmax;
        if (this.m_OutputControll < 0)
            return this.m_fUmin;
        return (this.m_fUmax + this.m_fUmin) / 2.0;  //taky parse?
    }
}
/////////////////////////////////////////////////////////
class Pol3Controller extends Pol2Controller {
    m_fUstr = 0.0;

    m_fNecit = 0.0;

    array_of_params = ["Umin", "Umax", "Hyst", "Ustr", "Necit"];

    Reset() {
        super.Reset();
        this.m_fUstr = 0.0;
        this.m_fNecit = 0.0;
    }

    setUstr(Value) {
        this.m_fUstr = Value;
    }

    setNecit(Value) {
        this.m_fNecit = Value;
    }

    setY(Y) {
        this.m_fY = Y;
        console.log(this.m_fY);
        if (this.m_fY < parseFloat(this.m_fW) - parseFloat(this.m_fNecit) - parseFloat(this.m_fHyst))
            this.m_OutputControll = 1;
        if (this.m_fY > parseFloat(this.m_fW) + parseFloat(this.m_fNecit) + parseFloat(this.m_fHyst))
            this.m_OutputControll = -1;
        //console.log(this.m_OutputControll);
        let a = parseFloat(this.m_fW) + parseFloat(this.m_fNecit) + parseFloat(this.m_fHyst);  //jde p�ed to d�t i pouze + https://stackoverflow.com/questions/7053511/javascript-sum-values
        console.log(a);
        console.log(this.m_fNecit);
        console.log(this.m_fHyst);
        if (this.m_fY > parseFloat(this.m_fW) - parseFloat(this.m_fNecit) + parseFloat(this.m_fHyst) && parseFloat(this.m_fY) < parseFloat(this.m_fW) + parseFloat(this.m_fNecit) - parseFloat(this.m_fHyst))  //tady n�jak probl�m!!!, asi necitlivost
            this.m_OutputControll = 0;
    }

    getU() {
        if (this.m_OutputControll > 0)
            return this.m_fUmax;
        if (this.m_OutputControll < 0)
            return this.m_fUmin;
        return this.m_fUstr;
    }
}