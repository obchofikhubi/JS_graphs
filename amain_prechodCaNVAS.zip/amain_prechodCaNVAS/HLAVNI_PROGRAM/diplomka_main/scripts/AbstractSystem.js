class AbstractSystem  {
    m_fD = 0.0;

    m_fU = 0.0;

    m_fW = 0.0;

    m_fY = 0.0;

    m_fSu = 0.0;

    m_fSd = 0.0;

    m_fA0 = 1.0;

    m_fA1 = 0.0;

    m_fA2 = 0.0;

    m_fA3 = 0.0;

    m_fA4 = 0.0;

    m_fdT = 0.1;  // vzorkovac� perioda
    

    m_aLast = [4];  //????
    
    m_fDMax = 10000;//Double.MAX_VALUE;

    m_fDMin = -10000;//Double.MIN_VALUE;

    m_fWMax = 10000; //Double.MAX_VALUE;

    m_fWMin = -10000;//Double.MIN_VALUE;

    m_fUMax = 10000;//Double.MAX_VALUE;

    m_fUMin = -10000;//Double.MIN_VALUE;

    m_fYMax = 10000;//Double.MAX_VALUE;

    m_fYMin = -10000;   //Double.MIN_VALUE;
    
    UpdateSystem() {
        for (let i = 3; i > 0; i--)
        this.m_aLast[i] = this.m_aLast[i - 1];
        this.m_aLast[0] = this.m_fY;

        let cast1 = this.m_fdT * (this.m_fD * this.m_fSd + this.m_fSu * this.m_fU);
        let cast2 = this.m_fdT * (this.m_fA1 * this.m_aLast[0] + cast1);
        let cast3 = this.m_fdT * (this.m_fA2 * (2.0 * this.m_aLast[0] - this.m_aLast[1]) + cast2);
        let cast4 = this.m_fdT * (this.m_fA3 * (3.0 * this.m_aLast[0] - 3.0 * this.m_aLast[1] + this.m_aLast[2]) + cast3);
        let citatel = cast4 - this.m_fA4 * (this.m_aLast[0] - 4.0 * this.m_aLast[1] + 3.0 * (2.0 * this.m_aLast[2] + this.m_aLast[3]));
        let jmenovatel = this.m_fdT * (this.m_fA3 + this.m_fdT * (this.m_fA2 + this.m_fdT * (this.m_fA1 + this.m_fdT * this.m_fA0)));

        if (citatel == 0.0) { 
            this.m_fY = 0.0;
        } else if (jmenovatel == 0.0) {
            this.m_fY = 0.0;
        } else {
            this.m_fY = citatel / jmenovatel;
        }
        //this.ApplyHWLimits();  ///////////////////////////////////////////////////////////////////////////////////////////// tady se limituje Y!!!!!!!!!!!!!!!!!
    }

    get_Y() {
        this.UpdateSystem();
       // repaint();
        return this.m_fY;
    }

    limit(what, from, to) {  // zatim pouze vrac� limitovanou hodnotu!
        what = (what < from) ? from : ((what > to) ? to : what);
        return what; // (what < from) ? from : ((what > to) ? to : what);
    }

    ApplyHWLimits() {
        this.m_fY = this.limit(this.m_fY, this.m_fYMin, this.m_fYMax);
    }
    
    setU(U) {
            this.m_fU = this.limit(U, this.m_fUMin, this.m_fUMax);
    }
    
    setD(D) {
          this.m_fD = this.limit(D, this.m_fDMin, this.m_fDMax);  // limit tu asi sta��, z�ejm� m��eme z enginu vyndat ten provizorn� limit (W,D)
    }
    
    setW(W) {
        this.m_fW = W; //this.limit(W, this.m_fWMin, this.m_fWMax);  //v Enginu to zat�m z�st�v�, proto�e W nen� u controlleru d�le limitovan�
    }

    setSu(Su) {
            this.m_fSu = Su;
    }

    setSd(Sd) {
            this.m_fSd = Sd;
    }

    setA0(A0) {
            this.m_fA0 = A0;
    }

   setA1(A1) {
            this.m_fA1 = A1;
    }

    setA2(A2) {
            this.m_fA2 = A2;
    }

    setA3(A3) {
            this.m_fA3 = A3;
    }

    setA4(A4) {
            this.m_fA4 = A4;
    }

    setdT(dT) {
       //  this.m_fdT != 0.0)
        this.m_fdT = dT;
    }
    
    Reset() {
        this.WTF = 1.0;
        this.m_fD = 0.0;
        this.m_fU = 0.0;
        this.m_fW = 0.0;
        this.m_fY = 0.0;
        this.m_fSu = 0.0;
        this.m_fSd = 0.0;
        this.m_fA1 = 0.0;
        this.m_fA2 = 0.0;
        this.m_fA3 = 0.0;
        this.m_fA4 = 0.0;
        this.m_fdT = 1.0;
         for (let i = 0; i < 4; i++) {
             this.m_aLast[i] = 0.0;
         }
    }
    
    constructor() {  
        this.Reset();  
    }
    
    
}