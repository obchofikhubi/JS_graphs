class AbstractController  {
    m_fY = 0.0;

    m_fW = 0.0;

    m_fdT = 1.0;

    array_of_params = [];  // mo�n� zbyte�n� i tady?

    Reset() {
        this.m_fY = 0.0;
        this.m_fW = 0.0;
        this.m_fdT = 1.0;
    }

    setY(Y) {
        this.m_fY = Y;
        
    }

    setW(W) {  // nikde nen� limit!!!!!!!!!!!!!!, u syst�mu to limitovan� je!!
        this.m_fW = W;
    }

    getU() {
        return this.m_fW - this.m_fY;
    }

    setdT(dT) {
        this.m_fdT = dT;
    }
    
}
