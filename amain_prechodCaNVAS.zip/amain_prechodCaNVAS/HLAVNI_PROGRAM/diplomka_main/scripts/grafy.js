var base = document.getElementById('myChart').getContext('2d');

document.getElementById("myChart").onclick = function (evt) {
    //var activePoints = myChart1.getElementsAtEvent(evt);
    console.log("OKEJ");
}
/*
let omfg = document.querySelector("#myChart");

omfg.addEventListener('click', () => {
    console.log("GGGG");
});

function fuckit() {
    console.log("GGGGGGGGGGGGG");
}
var graf = new Chart(base, {
    type: 'scatter',
    data: {
        datasets: [{
            data: [{ x: 0, y: 0 }],
            fill: false,
            label: 'ball position',  // tady lze d�t dal�� data, nap� ak�n� hodnotu
        }]
    },
    options: {
        
        scales: {

            yAxes: [{    //pokud je jen y, tak nefunguje...
                ticks: {
                    beginAtZero: true,
                    max: 150,
                    min: -150
                }
            }],
            xAxes: [{
                ticks: {
                    beginAtZero: true,
                    max: 200,
                    min: 0
                }
            }]

        }
    }
});

//global counter
var counter = 0;

function addValue1(valueToAdd) {
    if (graf.data.datasets[0].data.length > 200) {  //  poprve by nem�lo, u� je to 1!!
        graf.data.datasets[0].data.shift();
        updateScales();
    }
    counter = counter + 1;  // zmensit
    /*
    var znamenko = Math.random();
    var myVal = Math.random() * 50;
    if (znamenko < 0.5) {
        myVal = myVal * (-1);  // asi neefektivn�, pro n�zornost
    }
    */
    graf.data.datasets[0].data.push({ x: counter, y: valueToAdd });
    graf.update();
}
function updateScales() {
    graf.options.scales.xAxes[0].ticks.max = graf.options.scales.xAxes[0].ticks.max + 1;
    graf.options.scales.xAxes[0].ticks.min = graf.options.scales.xAxes[0].ticks.min + 1;
}
        /*
async function chartIt() {
    await getData();
    // tady update
}
*/