<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <style>
        .display-table {
            display: table;
        }

            .display-table > div {
                display: table-row;
            }

                .display-table > div > div {
                    display: table-cell;
                    padding: 5px;
                }
    </style>

    <!-- <link rel="stylesheet" type="text/css" href="style.css"> -->

</head>
<body>
    <div>
        <h1><a href="?page=kulicka_php">Kulicka</a></h1>
        <h1><a href="?page=nadrz_php">Nadrz</a></h1>
    </div>
    <div  width="500px" height="500px" style=" min-height: 500px; position: relative; text-align: center ">

        <canvas id="layer1" width="500" height="500" style="position:absolute; z-index: 0;"></canvas>  <!-- text-align:center;  style="position: absolute;  z-index: 0;"-->

        <canvas id="layer2" width="500" height="500" style="position: absolute;   z-index: 1;"></canvas> <!--style="position: absolute; left: 0; top: 0; z-index: 1;"-->


    </div>

    <!--
    <div style="text-align:center" id="myCanvas">
        <canvas>    </canvas>
    </div>
        -->
    <!--
    <div style="text-align:center" id="mySvg">

        <svg width="400" height="400" style="background-color:blue">

            <rect id="nadrz" x="5" y="5" width="150" height="150" stroke="red" stroke-width="10" />
            <polygon id="voda" points="10,5 150,5 150,150 10,150 " style="fill:lime;" />
        </svg>

    </div>
        -->

    <div style="position:relative">

        <div style="text-align:center">
            <button id="main-button">START</button>
            <button id="stop-button">STOP</button>
        </div>
        <br />
        <div style="text-align:center">
            <button id="P-cont">P-cont</button>
            <button id="I-cont">I-cont</button>
            <button id="PD-cont">PD-cont</button>
            <button id="PI-cont">PI-cont</button>
            <button id="PID-cont">PID-cont</button>
            <button id="pol2-cont">2pol-cont</button>
            <button id="pol3-cont">3pol-cont</button>
            <button id="manual-cont">manual</button>
        </div>
        <div style="display:table; margin-left:auto; margin-right:auto">
            <div style="display:table-cell" class="display-table">
                <!-- style="margin-left:auto; margin-right:auto" margin left/right centruje - pozor na block/inline elementy-->
                <div id="R0-row">
                    <div>Set R0:  <input type="number" id="R0-user" min="-150" max="150"> &nbsp R0 = <span id="R0-val">0</span></div>
                </div>
                <div id="Ti-row">
                    <div> Set  Ti:   <input type="number" id="Ti-user" min="-150" max="150">  &nbsp Ti = <span id="Ti-val">0</span></div>
                </div>
                <div id="Td-row">
                    <div>Set Td:  <input type="number" id="Td-user" min="-150" max="150">  &nbsp Td = <span id="Td-val">0</span></div>
                </div>

                <div id="Hyst-row">
                    <div>Set Hyst:  <input type="number" id="Hyst-user" min="-150" max="150"> &nbsp Hyst = <span id="Hyst-val">0</span></div>
                </div>
                <div id="Umin-row">
                    <div> Set  U-min:   <input type="number" id="Umin-user" min="-150" max="150">  &nbsp U-min = <span id="Umin-val">0</span></div>
                </div>
                <div id="Ustr-row">
                    <div>Set U-str:  <input type="number" id="Ustr-user" min="-150" max="150">  &nbsp U-str = <span id="Ustr-val">0</span></div>
                </div>
                <div id="Umax-row">
                    <div>Set U-max:  <input type="number" id="Umax-user" min="-150" max="150"> &nbsp U-max = <span id="Umax-val">0</span></div>
                </div>
                <div id="Necit-row">
                    <div> Set  Necit:   <input type="number" id="Necit-user" min="-150" max="150">  &nbsp Necit = <span id="Necit-val">0</span></div>
                </div>
                <div id="U-row">
                    <div>Set U:  <input type="number" id="U-user" min="-150" max="150">  &nbsp U = <span id="U-val">0</span></div>    <!-- dát jen do manual modu?? někde musí být U vidět-->
                </div>

            </div>
            <div style="display:table-cell" class="display-table">
                <div id="D-row">
                    <div>Set D:  <input type="number" id="D-user" min="-150" max="150"> &nbsp D = <span id="D-val">0</span></div>
                </div>
                <div id="W-row">
                    <div> Set  W:   <input type="number" id="W-user" min="-150" max="150">  &nbsp W = <span id="W-val">0</span></div>
                </div>

            </div>
        </div>

        <div style="text-align:center">
            <button id="conf-button">confirm</button>
        </div>
        <div class="col-md-6 offset-md-3">
            <!--máme bootstrap v headu, zatím asi neřešit esetetiku detailně-->
            <div class="card">

                <div class="card-body">
                    <!--
                <h1>
                    Charts, Charts
                    <button class="btn btn-info" onclick="addValue1(5)">+1</button>
                            </h1>
                            -->
                </div>
                <div class="card-body">
                    <canvas id="myChart1" width="800" height="500"></canvas>
                </div>

            </div>
        </div>
    </div>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>



    <script src="Engine.js"></script>
    <script src="AbstractController.js"></script>
    <script src="AbstractSystem.js"></script>
    <script src="Controllers.js"></script>

    <script src="nadrzSVodou.js"></script>
    <script src="grafy.js"></script>
    <script src="anime.min.js"></script>

</body>

</html>