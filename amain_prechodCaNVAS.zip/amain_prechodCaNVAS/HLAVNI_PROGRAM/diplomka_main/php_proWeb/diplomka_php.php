﻿<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <style>
    </style>

    <!-- FUUUUUUUUUUUUUUUU <link rel="stylesheet" type="text/css" href="style.css"> -->

</head>
<body>
   <div>
         <h1><a href="?page=kulicka_php">Kulicka</a></h1>
        <h1><a href="?page=nadrz_php">Nadrz</a></h1>
    </div>
</body>

</html>