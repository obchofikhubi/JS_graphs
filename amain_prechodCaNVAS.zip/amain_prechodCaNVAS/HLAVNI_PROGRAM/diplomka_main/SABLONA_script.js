par_Su_val = 1.6;  
par_Sd_val = 0;
par_a0_val = 0;   // POZOR, NEBYLO TO NIKDE, // 1 - statick� soustava, 0 - astatick� soustava
par_a1_val = 0;
par_a2_val = 1;
par_a3_val = 0;
par_a4_val = 0;
par_Astatic_val = true;  
par_dT_val = 0.3;
par_DMin_val = 0;
par_DMax_val = 100;
par_WMin_val = 0;
par_WMax_val = 60;
par_UMin_val = -100;
par_UMax_val = 100;  
par_YMin_val = 0;
par_YMax_val = 60;


par_PR0 = { 
    val: 0.05,
    min: 0,
    max: 5
};
par_ITi = {
    val: 20000,
    min: 1,
    max: 50000
};
par_PIR0 = {
    val: 0.05,
    min: 0,
    max: 1
};
par_PITi = {
    val: 5,
    min: 1,
    max: 99
};
par_PDR0 = {
    val: 0.05,
    min: 0,
    max: 5
};
par_PDTd = {
    val: 7,
    min: 0,
    max: 10
};
par_PIDR0 = {
    val: 0.05,
    min: 0,
    max: 2
};
par_PIDTi = {
    val: 60,
    min: 1,
    max: 99
};
par_PIDTd = {
    val: 14,
    min: 0,
    max: 50
};
par_Pol2Hyst = {  // p�edtim bylo POL, upraveno aby se shodovalo s konstruktorem
    val: 10,
    min: 1,
    max: 100
};
par_Pol2Umax = {
    val: 0.5,
    min: -5,
    max: 5
};
par_Pol2Umin = {
    val: -0.5,
    min: -5,
    max: 5
};
par_Pol3Hyst = {
    val: 10,
    min: 1,
    max: 100
};
par_Pol3Necit = {
    val: 30,
    min: 0,
    max: 50
};
par_Pol3Umax = {
    val: 0.5,
    min: -5,
    max: 5
};
par_Pol3Ustr = {
    val: 0,
    min: -5,
    max: 5
};
par_Pol3Umin = {
    val: -0.5,
    min: -5,
    max: 5
};


// geometrie konkr�tn� �lohy

let centerX = 250;
let centerY = 250;  
let circleX = 0;
let circleY = 0;
let l = 240;  
let R = 15;
let fi = 0; 

/////////////////////////////////////////////////////////////////////////////////////////

// canvas - svg


const canvas1 = document.getElementById('layer1');
const canvas2 = document.getElementById('layer2');
canvas1.width = 500;
canvas1.height = 500;
canvas2.width = 500;
canvas2.height = 500;  // ? neni zbytecne??

const c1 = canvas1.getContext('2d');
const c2 = canvas2.getContext('2d');

const backgroundImg = new Image(canvas1.width, canvas1.height);  
backgroundImg.src = '"           ".gif';
backgroundImg.onload = function () {  
    c1.drawImage(backgroundImg, 0, 0, canvas1.width, canvas1.height);
}




class WaterTank extends AbstractSystem {

    constructor() {
        super();  // tady asi nep�i�azovat nic???

        this.m_fDMax = par_DMax_val
        this.m_fDMin = par_DMin_val;
        this.m_fWMax = par_WMax_val;   // tohle d�l� probl�m, mus�me pouze limitovat vstup!!!!!!!!!
        this.m_fWMin = par_WMin_val;
        this.m_fUMax = par_UMax_val;
        this.m_fUMin = par_UMin_val;
        this.m_fYMax = par_YMax_val;
        this.m_fYMin = par_YMin_val;

        this.m_fA0 = par_a0_val;
        this.m_fA1 = par_a1_val;
        this.m_fA2 = par_a2_val;
        this.m_fA3 = par_a3_val;
        this.m_fA4 = par_a4_val;
        this.m_fSd = par_Sd_val;
        this.m_fSu = par_Su_val;
        this.m_fdT = par_dT_val;
    }


    draw() {
       
    }

}

//engine a syst�m
let mainEngine = new Engine();
let system = new WaterTank();
mainEngine.SetSystem(system);
system.draw();  // aby do�lo k prvn�mu vykreslen� p�ed startem... cel� asi d�t do n�jak� funkce init

